# EXRGarage — Tuning Tools

Interactive browser tools for the EXRGarage motorcycle chassis on Roblox.

🔗 **Live Site:** https://6rfxn.github.io/Motorcycle-Top-Speed-Reference/

## Tools

- **Gear Ratio Calculator** — Generate smooth gear ratios with adjustable bias, preview gear spacing visually, and copy Lua output directly into your Tune script.

## Setup — GitHub Pages

### Step 1: Add the files to your repo

Copy the `docs` folder structure into your repo root:

```
Motorcycle-Top-Speed-Reference/
├── docs/
│   ├── index.html                          ← Landing page
│   └── tools/
│       └── gear-ratio-calculator.html      ← Calculator
├── README.md
└── (your other files)
```

### Step 2: Enable GitHub Pages

1. Go to your repo on GitHub
2. Click **Settings** → **Pages** (left sidebar)
3. Under **Source**, select:
   - Branch: `main`
   - Folder: `/docs`
4. Click **Save**
5. Wait 1–2 minutes for it to deploy

### Step 3: Access your site

Your site will be live at:
```
https://6rfxn.github.io/Motorcycle-Top-Speed-Reference/
```

The gear ratio calculator will be at:
```
https://6rfxn.github.io/Motorcycle-Top-Speed-Reference/tools/gear-ratio-calculator.html
```

## Adding New Tools

1. Create a new `.html` file in `docs/tools/`
2. Add a card link in `docs/index.html` under the `tools-grid` div
3. Push and it auto-deploys
